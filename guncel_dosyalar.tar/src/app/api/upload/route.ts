import { NextRequest, NextResponse } from "next/server";
import { mkdir } from "fs/promises";
import path from "path";
import { existsSync, createWriteStream } from "fs";
import { getToken } from "next-auth/jwt";
import { pipeline } from "stream/promises";

export async function POST(request: NextRequest) {
    try {
        const token = await getToken({ req: request });
        if (!token || token.role !== "ADMIN") {
            return NextResponse.json({ error: "Yetkisiz erişim. Dosya yüklemek için Admin girişi gereklidir." }, { status: 401 });
        }
        const formData = await request.formData();
        const file = formData.get("file") as File;

        if (!file) {
            return NextResponse.json({ error: "Dosya bulunamadı" }, { status: 400 });
        }

        // Validate file type
        const allowedTypes = [
            "image/jpeg", "image/png", "image/webp", "image/gif", "image/svg+xml",
            "video/mp4", "video/webm", "video/ogg", "video/quicktime"
        ];
        if (!allowedTypes.includes(file.type)) {
            return NextResponse.json({ error: "Geçersiz dosya formatı. Resim (JPG, PNG vb.) veya Video (MP4, WEBM vb.) yükleyin." }, { status: 400 });
        }

        // Validate file size (max 2000MB)
        if (file.size > 2000 * 1024 * 1024) {
            return NextResponse.json({ error: "Dosya boyutu sistem sınırını aştı." }, { status: 400 });
        }

        // Create upload directory if it doesn't exist
        const uploadDir = path.join(process.cwd(), "public", "uploads");
        if (!existsSync(uploadDir)) {
            await mkdir(uploadDir, { recursive: true });
        }

        // Generate unique filename
        const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
        const uniqueName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        const filePath = path.join(uploadDir, uniqueName);

        // Write file using Streams to save memory
        const writeStream = createWriteStream(filePath);
        // @ts-ignore
        const reader = file.stream().getReader();
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            writeStream.write(value);
        }
        writeStream.end();

        // Return public URL (Served by our uploads router or nginx)
        const url = `/uploads/${uniqueName}`;
        return NextResponse.json({ url, success: true });
    } catch (error) {
        console.error("Upload error:", error);
        return NextResponse.json({ error: "Dosya yüklenirken hata oluştu." }, { status: 500 });
    }
}
