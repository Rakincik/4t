"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

export async function getFlixPackages() {
    return prisma.course.findMany({
        where: { type: "FLIX" as any },
        orderBy: { createdAt: "desc" },
        include: {
            _count: { select: { orderItems: true, courseAccess: true } },
            variants: { orderBy: { order: 'asc'} }
        },
    });
}

export async function getFlixPackage(id: string) {
    return prisma.course.findUnique({ 
        where: { id },
        include: { variants: { orderBy: { order: 'asc'} } }
    });
}

function parseFlixFormData(formData: FormData) {
    return {
        title: formData.get("title") as string,
        slug: formData.get("slug") as string,
        subtitle: formData.get("subtitle") as string || null,
        description: formData.get("description") as string || null,
        price: parseFloat(formData.get("price") as string) || 0,
        oldPrice: formData.get("oldPrice") ? parseFloat(formData.get("oldPrice") as string) : null,
        imageUrl: formData.get("imageUrl") as string || null,
        videoUrl: formData.get("videoUrl") as string || null,
        category: "flix",
        type: "FLIX" as any,
        isActive: formData.get("isActive") === "true",
        isCouponApplicable: formData.get("isCouponApplicable") !== "false",
        hours: formData.get("hours") as string || null,
        questions: formData.get("questions") as string || null,
        bookPrice: formData.get("bookPrice") ? parseFloat(formData.get("bookPrice") as string) : null,
        badge: formData.get("badge") as string || null,
        features: formData.get("features") ? JSON.parse(formData.get("features") as string) : null,
        episodes: formData.get("episodes") ? JSON.parse(formData.get("episodes") as string) : null,
        cast: formData.get("cast") ? JSON.parse(formData.get("cast") as string) : null,
        tags: formData.get("tags") ? JSON.parse(formData.get("tags") as string) : null,
    };
}

function parseRelations(formData: FormData) {
    const variantsList = formData.get("variants") ? JSON.parse(formData.get("variants") as string) : [];
    return {
        variants: variantsList.map((v: any, i: number) => ({ title: v.title, price: Number(v.price), oldPrice: v.oldPrice ? Number(v.oldPrice) : null, accessDurationDays: v.accessDurationDays ? Number(v.accessDurationDays) : null, order: i }))
    };
}

function revalidateFlixPaths(slug?: string) {
    revalidatePath("/admin/flix");
    revalidatePath("/flix");
    if (slug) revalidatePath(`/flix/${slug}`);
}

export async function createFlixPackage(formData: FormData) {
    const data = parseFlixFormData(formData);
    const rels = parseRelations(formData);
    const pkg = await prisma.course.create({ 
        data: {
            ...data,
            variants: { create: rels.variants }
        }
    });
    revalidateFlixPaths();
    return { success: true, id: pkg.id };
}

export async function updateFlixPackage(id: string, formData: FormData) {
    const data = parseFlixFormData(formData);
    const rels = parseRelations(formData);
    
    await prisma.courseVariant.deleteMany({ where: { courseId: id } });
    
    await prisma.course.update({ 
        where: { id }, 
        data: {
            ...data,
            variants: { create: rels.variants }
        }
    });
    revalidateFlixPaths(data.slug);
    return { success: true };
}

export async function deleteFlixPackage(id: string) {
    await prisma.course.delete({ where: { id } });
    revalidateFlixPaths();
    return { success: true };
}
