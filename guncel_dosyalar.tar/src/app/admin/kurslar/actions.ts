"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

// ============================================
// Course CRUD
// ============================================
export async function getCourses() {
    return prisma.course.findMany({
        include: { variants: { orderBy: { order: 'asc'} }, addons: { orderBy: { order: 'asc'} } },
        orderBy: { createdAt: "desc" },
    });
}

export async function getCourse(id: string) {
    return prisma.course.findUnique({
        where: { id },
        include: { variants: { orderBy: { order: 'asc'} }, addons: { orderBy: { order: 'asc'} }, coupons: { orderBy: { createdAt: 'desc' } } },
    });
}

function parseFormData(formData: FormData) {
    return {
        title: formData.get("title") as string,
        slug: formData.get("slug") as string,
        color: formData.get("color") as string || "#3B82F6",
        emoji: formData.get("emoji") as string || null,
        subtitle: formData.get("subtitle") as string || null,
        description: formData.get("description") as string || null,
        price: parseFloat(formData.get("price") as string) || 0,
        oldPrice: formData.get("oldPrice") ? parseFloat(formData.get("oldPrice") as string) : null,
        imageUrl: formData.get("imageUrl") as string || null,
        gallery: formData.get("gallery") ? JSON.parse(formData.get("gallery") as string) : null,
        videoUrl: formData.get("videoUrl") as string || null,
        category: formData.get("category") as string || null,
        type: (formData.get("type") as string || "KURS") as any,
        isActive: formData.get("isActive") === "true",
        isCouponApplicable: formData.get("isCouponApplicable") !== "false",
        hours: formData.get("hours") as string || null,
        questions: formData.get("questions") as string || null,
        bookPrice: formData.get("bookPrice") ? parseFloat(formData.get("bookPrice") as string) : null,
        badge: formData.get("badge") as string || null,
        duration: formData.get("duration") as string || null,
        studentCount: formData.get("studentCount") as string || null,
        resources: formData.get("resources") as string || null,
        features: formData.get("features") ? JSON.parse(formData.get("features") as string) : null,
        learningOutcomes: formData.get("learningOutcomes") ? JSON.parse(formData.get("learningOutcomes") as string) : null,
        curriculum: formData.get("curriculum") ? JSON.parse(formData.get("curriculum") as string) : null,
        instructor: formData.get("instructor") ? JSON.parse(formData.get("instructor") as string) : null,
        episodes: formData.get("episodes") ? JSON.parse(formData.get("episodes") as string) : null,
        cast: formData.get("cast") ? JSON.parse(formData.get("cast") as string) : null,
        tags: formData.get("tags") ? JSON.parse(formData.get("tags") as string) : null,
        accessEndDate: formData.get("accessEndDate") ? new Date(formData.get("accessEndDate") as string) : null,
        accessDurationDays: formData.get("accessDurationDays") ? parseInt(formData.get("accessDurationDays") as string) : null,
    };
}

function parseRelations(formData: FormData) {
    const variantsList = formData.get("variants") ? JSON.parse(formData.get("variants") as string) : [];
    const addonsList = formData.get("addons") ? JSON.parse(formData.get("addons") as string) : [];
    const couponsList = formData.get("coupons") ? JSON.parse(formData.get("coupons") as string) : [];
    return {
        variants: variantsList.map((v: any, i: number) => ({ title: v.title, price: Number(v.price), oldPrice: v.oldPrice ? Number(v.oldPrice) : null, order: i })),
        addons: addonsList.map((a: any, i: number) => ({ title: a.title, price: Number(a.price), order: i })),
        coupons: couponsList.map((c: any) => ({
            id: c.id || undefined,
            code: c.code, type: c.type, amount: Number(c.amount),
            maxUses: c.maxUses ? Number(c.maxUses) : null,
            expiresAt: c.expiresAt ? new Date(c.expiresAt) : null,
            isActive: c.isActive ?? true,
        }))
    };
}

function revalidateAll(slug?: string) {
    revalidatePath("/admin/kurslar");
    revalidatePath("/admin/kurslar/[id]", "page");
    revalidatePath("/kurslar");
    revalidatePath("/flix");
    revalidatePath("/kamplar");
    if (slug) revalidatePath(`/kurs/${slug}`);
}

export async function createCourse(formData: FormData) {
    const data = parseFormData(formData);
    const rels = parseRelations(formData);
    const course = await prisma.course.create({ 
        data: {
            ...data,
            variants: { create: rels.variants },
            addons: { create: rels.addons }
        } 
    });
    // Create coupons linked to this course
    if (rels.coupons.length > 0) {
        for (const c of rels.coupons) {
            await prisma.coupon.create({ data: { code: c.code, type: c.type, amount: c.amount, maxUses: c.maxUses, expiresAt: c.expiresAt, isActive: c.isActive, courseId: course.id } });
        }
    }
    revalidateAll();
    return { success: true, id: course.id };
}

export async function updateCourse(id: string, formData: FormData) {
    const data = parseFormData(formData);
    const rels = parseRelations(formData);
    
    // Perform inline delete-and-create for relations
    await prisma.courseVariant.deleteMany({ where: { courseId: id } });
    await prisma.courseAddon.deleteMany({ where: { courseId: id } });
    
    await prisma.course.update({ 
        where: { id }, 
        data: {
            ...data,
            variants: { create: rels.variants },
            addons: { create: rels.addons }
        } 
    });
    // Sync coupons: upsert existing, create new, delete removed
    const existingCoupons = await prisma.coupon.findMany({ where: { courseId: id } });
    const submittedIds = rels.coupons.filter((c: any) => c.id).map((c: any) => c.id);
    // Delete removed coupons
    const toDelete = existingCoupons.filter(ec => !submittedIds.includes(ec.id));
    for (const d of toDelete) { await prisma.coupon.delete({ where: { id: d.id } }); }
    // Upsert coupons
    for (const c of rels.coupons) {
        if (c.id) {
            await prisma.coupon.update({ where: { id: c.id }, data: { code: c.code, type: c.type, amount: c.amount, maxUses: c.maxUses, expiresAt: c.expiresAt, isActive: c.isActive } });
        } else {
            await prisma.coupon.create({ data: { code: c.code, type: c.type, amount: c.amount, maxUses: c.maxUses, expiresAt: c.expiresAt, isActive: c.isActive, courseId: id } });
        }
    }
    revalidateAll(data.slug);
    return { success: true };
}

export async function deleteCourse(id: string) {
    await prisma.course.delete({ where: { id } });
    revalidateAll();
    return { success: true };
}
