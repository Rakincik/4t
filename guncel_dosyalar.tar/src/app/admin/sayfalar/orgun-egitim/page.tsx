"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import {
    AcademicCapIcon, MapPinIcon, UserGroupIcon, SparklesIcon,
    PlusIcon, TrashIcon, PhotoIcon, ChevronDownIcon,
    ComputerDesktopIcon, DevicePhoneMobileIcon, ArrowsPointingOutIcon, ArrowsPointingInIcon,
    ArrowPathIcon, MagnifyingGlassMinusIcon, MagnifyingGlassPlusIcon,
    BuildingLibraryIcon, ClockIcon,
} from "@heroicons/react/24/outline";
import RichTextEditor from "@/app/admin/components/RichTextEditor";
import SortableList from "@/app/admin/components/SortableList";
import VersionHistory from "@/app/admin/components/VersionHistory";
import ResizableSplitter from "@/app/components/ResizableSplitter";

type SectionId = "location" | "programs" | "faculty" | "timeline";
const SECTION_META: Record<SectionId, { label: string; icon: any; color: string }> = {
    location: { label: "Lokasyon", icon: MapPinIcon, color: "text-red-500 bg-red-50" },
    programs: { label: "Eğitim Modeli", icon: AcademicCapIcon, color: "text-blue-500 bg-blue-50" },
    faculty: { label: "Eğitmen Kadrosu", icon: UserGroupIcon, color: "text-purple-500 bg-purple-50" },
    timeline: { label: "Başarı Adımları", icon: SparklesIcon, color: "text-green-500 bg-green-50" },
};

type ProgramItem = { title: string; desc: string };
type TeacherItem = { name: string; title: string; imgUrl: string };
type StepItem = { title: string; desc: string };

export default function OrgunEgitimEditorPage() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
    const [hasChanges, setHasChanges] = useState(false);
    const [activeSection, setActiveSection] = useState<SectionId>("location");
    const [expandedSections, setExpandedSections] = useState<Set<SectionId>>(new Set(["location"]));
    const [previewDevice, setPreviewDevice] = useState<"desktop" | "mobile">("desktop");
    const [previewZoom, setPreviewZoom] = useState(65);
    const [previewFullscreen, setPreviewFullscreen] = useState(false);
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const [reloadKey, setReloadKey] = useState(0);

    // Location
    const [locTitle, setLocTitle] = useState("Ankara'nın Kalbinde, Ulaşımın Merkezinde.");
    const [locDesc, setLocDesc] = useState("Kızılay Metro istasyonuna 2 dakika yürüme mesafesinde.");
    const [locAddress, setLocAddress] = useState("Karanfil Sokak No: 44, Kızılay");
    const [locHours, setLocHours] = useState("09:00 - 23:00");
    const [progSectionTitle, setProgSectionTitle] = useState("Neden 4T Örgün Eğitim?");
    const [programs, setPrograms] = useState<ProgramItem[]>([
        { title: "Tam Kapsamlı Konu Anlatımı", desc: "Alanında uzman hocalarımızla tüm dersleri en ince ayrıntısına kadar işliyoruz." },
        { title: "Birebir Soru Çözüm & Etüt", desc: "Anlamadığınız konu veya çözemediğiniz soru kalmayacak." },
        { title: "Sınırsız Kaynak Desteği", desc: "4T Yayınevi'nin tüm kaynaklarına ücretsiz erişim." },
        { title: "Türkiye Geneli Denemeler", desc: "Gerçek sınav provası niteliğinde denemeler." },
    ]);
    const [facTitle, setFacTitle] = useState("Şampiyonlar Ligi.");
    const [facDesc, setFacDesc] = useState("Sınav kazandıran kadro, sadece Ankara kampüsünde sizlerle.");
    const [teachers, setTeachers] = useState<TeacherItem[]>([
        { name: "Prof. Dr. Yüksel Bilgili", title: "İktisat Duayeni", imgUrl: "" },
        { name: "Ahmet Albayrak", title: "Anayasa Hukuku", imgUrl: "" },
        { name: "Zeynep Yılmaz", title: "Muhasebe Uzmanı", imgUrl: "" },
        { name: "Mehmet Öztürk", title: "Tarih Bölüm Başkanı", imgUrl: "" },
    ]);
    const [timelineTitle, setTimelineTitle] = useState("Kazanma Garantili Sistem.");
    const [steps, setSteps] = useState<StepItem[]>([
        { title: "Seviye Belirleme", desc: "İlk gün yapılan deneme ile size en uygun sınıfı belirliyoruz." },
        { title: "Kamp Programı", desc: "Eksiklerinizi kapatmak için yoğunlaştırılmış konu anlatım kampları." },
        { title: "Soru Çözüm Etütleri", desc: "Haftalık düzenli denemeler ve birebir soru çözüm saatleri." },
        { title: "Zirveye Yolculuk", desc: "Sınav provası niteliğinde Türkiye geneli denemeler ve son taktikler." },
    ]);

    const loadData = useCallback(async () => {
        try {
            const res = await fetch("/api/admin/page-content?page=orgun-egitim");
            const data = await res.json();
            if (data.location?.metadata) {
                if (data.location.title) setLocTitle(data.location.title);
                if (data.location.content) setLocDesc(data.location.content);
                if (data.location.metadata.address) setLocAddress(data.location.metadata.address);
                if (data.location.metadata.hours) setLocHours(data.location.metadata.hours);
            }
            if (data.programs?.metadata) {
                if (data.programs.title) setProgSectionTitle(data.programs.title);
                if (data.programs.metadata.items) setPrograms(data.programs.metadata.items);
            }
            if (data.faculty?.metadata) {
                if (data.faculty.title) setFacTitle(data.faculty.title);
                if (data.faculty.content) setFacDesc(data.faculty.content);
                if (data.faculty.metadata.items) setTeachers(data.faculty.metadata.items);
            }
            if (data.timeline?.metadata) {
                if (data.timeline.title) setTimelineTitle(data.timeline.title);
                if (data.timeline.metadata.items) setSteps(data.timeline.metadata.items);
            }
        } catch (e) { console.error(e); }
        finally { setLoading(false); setHasChanges(false); }
    }, []);

    useEffect(() => { loadData(); }, [loadData, reloadKey]);

    useEffect(() => { if (!loading) setHasChanges(true); }, [locTitle, locDesc, locAddress, locHours, progSectionTitle, programs, facTitle, facDesc, teachers, timelineTitle, steps]);

    const handleSave = useCallback(async () => {
        setSaving(true); setSaveStatus("saving");
        try {
            await fetch("/api/admin/page-content", {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    pageSlug: "orgun-egitim",
                    sections: {
                        location: { title: locTitle, content: locDesc, metadata: { address: locAddress, hours: locHours } },
                        programs: { title: progSectionTitle, content: null, metadata: { items: programs } },
                        faculty: { title: facTitle, content: facDesc, metadata: { items: teachers } },
                        timeline: { title: timelineTitle, content: null, metadata: { items: steps } },
                    },
                }),
            });
            setSaveStatus("saved"); setHasChanges(false);
            setTimeout(() => { if (iframeRef.current) iframeRef.current.src = iframeRef.current.src; }, 300);
            setTimeout(() => setSaveStatus("idle"), 3000);
        } catch { setSaveStatus("error"); setTimeout(() => setSaveStatus("idle"), 3000); }
        finally { setSaving(false); }
    }, [locTitle, locDesc, locAddress, locHours, progSectionTitle, programs, facTitle, facDesc, teachers, timelineTitle, steps]);

    function toggleSection(id: SectionId) { setActiveSection(id); setExpandedSections(prev => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; }); }

    const inputCls = "w-full px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition bg-white";
    const labelCls = "block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1";

    if (loading) return <div className="flex items-center justify-center h-[calc(100vh-120px)]"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600 mx-auto" /></div>;

    return (
        <div className={previewFullscreen ? "fixed inset-0 z-50 bg-gray-100" : ""} style={{ height: previewFullscreen ? "100vh" : "calc(100vh - 120px)" }}>
            <div className="flex h-full gap-0 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                {/* LEFT NAV */}
                <div className="w-52 bg-gray-50 border-r border-gray-200 flex flex-col shrink-0">
                    <div className="px-4 py-4 border-b border-gray-200">
                        <div className="flex items-center justify-between">
                            <h2 className="text-sm font-bold text-gray-900">Örgün Eğitim</h2>
                            <VersionHistory pageSlug="orgun-egitim" onRestore={() => { setReloadKey(k => k + 1); setLoading(true); }} />
                        </div>
                        <p className="text-[10px] text-gray-400 mt-0.5">Sayfa İçerik Editörü</p>
                    </div>
                    <div className="flex-1 overflow-y-auto py-2">
                        {(Object.keys(SECTION_META) as SectionId[]).map(id => {
                            const m = SECTION_META[id]; const Icon = m.icon; const isActive = activeSection === id;
                            return (
                                <button key={id} onClick={() => toggleSection(id)} className={`w-full px-4 py-3 flex items-center gap-3 text-left transition ${isActive ? "bg-white border-r-2 border-blue-600 shadow-sm" : "hover:bg-white/60"}`}>
                                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isActive ? m.color : "bg-gray-100 text-gray-400"}`}><Icon className="w-4 h-4" /></div>
                                    <p className={`text-xs font-semibold truncate ${isActive ? "text-gray-900" : "text-gray-600"}`}>{m.label}</p>
                                </button>
                            );
                        })}
                    </div>
                    <div className="px-4 py-3 border-t border-gray-200">
                        <button onClick={handleSave} disabled={saving || !hasChanges} className={`w-full py-2.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 ${saveStatus === "saved" ? "bg-emerald-500 text-white" : hasChanges ? "bg-[#0B1221] text-white hover:bg-[#1a2744]" : "bg-gray-100 text-gray-400 cursor-not-allowed"}`}>
                            {saveStatus === "saving" && <ArrowPathIcon className="w-3.5 h-3.5 animate-spin" />}
                            {saveStatus === "saving" ? "Kaydediliyor..." : saveStatus === "saved" ? "✓ Kaydedildi!" : hasChanges ? "💾 Kaydet" : "Değişiklik Yok"}
                        </button>
                    </div>
                </div>

                {/* CENTER + RIGHT: EDITOR & LIVE PREVIEW */}
                <ResizableSplitter minWidth={360} maxWidth={900} defaultWidth={480}>
                {/* CENTER EDITOR */}
                <div className="flex-1 overflow-y-auto bg-gray-50/50" style={{ minWidth: 0 }}>
                    <div className="p-5 space-y-4 max-w-2xl">
                        {/* LOCATION */}
                        <SectionAccordion id="location" active={activeSection} expanded={expandedSections} toggle={toggleSection}>
                            <div className="space-y-3">
                                <div><label className={labelCls}>Başlık</label><input className={inputCls} value={locTitle} onChange={e => setLocTitle(e.target.value)} /></div>
                                <div><label className={labelCls}>Açıklama</label><RichTextEditor value={locDesc} onChange={setLocDesc} placeholder="Lokasyon açıklaması..." minRows={3} /></div>
                                <div className="grid grid-cols-2 gap-3">
                                    <div><label className={labelCls}>Adres</label><input className={inputCls} value={locAddress} onChange={e => setLocAddress(e.target.value)} /></div>
                                    <div><label className={labelCls}>Çalışma Saatleri</label><input className={inputCls} value={locHours} onChange={e => setLocHours(e.target.value)} /></div>
                                </div>
                            </div>
                        </SectionAccordion>

                        {/* PROGRAMS */}
                        <SectionAccordion id="programs" active={activeSection} expanded={expandedSections} toggle={toggleSection}>
                            <div className="space-y-3">
                                <div><label className={labelCls}>Bölüm Başlığı</label><input className={inputCls} value={progSectionTitle} onChange={e => setProgSectionTitle(e.target.value)} /></div>
                                <label className={labelCls}>Program Kartları</label>
                                <SortableList
                                    items={programs}
                                    onChange={setPrograms}
                                    renderItem={(p, i) => (
                                        <div className="flex items-start gap-2 bg-white rounded-lg border border-gray-100 p-2">
                                            <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-[10px] font-bold shrink-0 mt-1">{i + 1}</span>
                                            <div className="flex-1 space-y-1">
                                                <input className={inputCls + " font-medium"} value={p.title} onChange={e => { const n = [...programs]; n[i] = { ...n[i], title: e.target.value }; setPrograms(n); }} placeholder="Başlık" />
                                                <input className={inputCls} value={p.desc} onChange={e => { const n = [...programs]; n[i] = { ...n[i], desc: e.target.value }; setPrograms(n); }} placeholder="Açıklama" />
                                            </div>
                                            <button onClick={() => setPrograms(programs.filter((_, idx) => idx !== i))} className="p-1 text-red-400 hover:text-red-600 mt-1"><TrashIcon className="w-3.5 h-3.5" /></button>
                                        </div>
                                    )}
                                />
                                <button onClick={() => setPrograms([...programs, { title: "", desc: "" }])} className="mt-2 text-[10px] text-blue-600 font-bold flex items-center gap-1 hover:underline"><PlusIcon className="w-3 h-3" /> Program Ekle</button>
                            </div>
                        </SectionAccordion>

                        {/* FACULTY */}
                        <SectionAccordion id="faculty" active={activeSection} expanded={expandedSections} toggle={toggleSection}>
                            <div className="space-y-3">
                                <div className="grid grid-cols-2 gap-3">
                                    <div><label className={labelCls}>Başlık</label><input className={inputCls} value={facTitle} onChange={e => setFacTitle(e.target.value)} /></div>
                                    <div><label className={labelCls}>Açıklama</label><input className={inputCls} value={facDesc} onChange={e => setFacDesc(e.target.value)} /></div>
                                </div>
                                <label className={labelCls}>Eğitmenler</label>
                                <SortableList
                                    items={teachers}
                                    onChange={setTeachers}
                                    renderItem={(t, i) => (
                                        <div className="flex items-center gap-2 bg-white rounded-lg border border-gray-100 p-2">
                                            <input className="flex-1 px-2 py-1.5 rounded border border-gray-200 text-sm font-medium focus:outline-none focus:border-blue-400" value={t.name} onChange={e => { const n = [...teachers]; n[i] = { ...n[i], name: e.target.value }; setTeachers(n); }} placeholder="İsim" />
                                            <input className="w-32 px-2 py-1.5 rounded border border-gray-200 text-sm focus:outline-none focus:border-blue-400" value={t.title} onChange={e => { const n = [...teachers]; n[i] = { ...n[i], title: e.target.value }; setTeachers(n); }} placeholder="Ünvan" />
                                            <button onClick={() => setTeachers(teachers.filter((_, idx) => idx !== i))} className="p-1 text-red-400 hover:text-red-600"><TrashIcon className="w-3.5 h-3.5" /></button>
                                        </div>
                                    )}
                                />
                                <button onClick={() => setTeachers([...teachers, { name: "", title: "", imgUrl: "" }])} className="mt-2 text-[10px] text-blue-600 font-bold flex items-center gap-1 hover:underline"><PlusIcon className="w-3 h-3" /> Eğitmen Ekle</button>
                            </div>
                        </SectionAccordion>

                        {/* TIMELINE */}
                        <SectionAccordion id="timeline" active={activeSection} expanded={expandedSections} toggle={toggleSection}>
                            <div className="space-y-3">
                                <div><label className={labelCls}>Bölüm Başlığı</label><input className={inputCls} value={timelineTitle} onChange={e => setTimelineTitle(e.target.value)} /></div>
                                <label className={labelCls}>Adımlar</label>
                                <SortableList
                                    items={steps}
                                    onChange={setSteps}
                                    renderItem={(s, i) => (
                                        <div className="flex items-start gap-2 bg-white rounded-lg border border-gray-100 p-2">
                                            <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center text-red-600 text-[10px] font-bold shrink-0 mt-1">{i + 1}</div>
                                            <div className="flex-1 space-y-1">
                                                <input className={inputCls + " font-medium"} value={s.title} onChange={e => { const n = [...steps]; n[i] = { ...n[i], title: e.target.value }; setSteps(n); }} placeholder="Adım başlığı" />
                                                <input className={inputCls} value={s.desc} onChange={e => { const n = [...steps]; n[i] = { ...n[i], desc: e.target.value }; setSteps(n); }} placeholder="Açıklama" />
                                            </div>
                                            <button onClick={() => setSteps(steps.filter((_, idx) => idx !== i))} className="p-1 text-red-400 hover:text-red-600 mt-1"><TrashIcon className="w-3.5 h-3.5" /></button>
                                        </div>
                                    )}
                                />
                                <button onClick={() => setSteps([...steps, { title: "", desc: "" }])} className="mt-2 text-[10px] text-blue-600 font-bold flex items-center gap-1 hover:underline"><PlusIcon className="w-3 h-3" /> Adım Ekle</button>
                            </div>
                        </SectionAccordion>
                    </div>
                </div>

                {/* RIGHT PREVIEW */}
                <div className={`border-l border-gray-200 flex flex-col bg-gray-100 ${previewFullscreen ? "flex-[2]" : ""}`} style={{ width: previewFullscreen ? undefined : 480 }}>
                    <div className="px-3 py-2 bg-white border-b border-gray-200 flex items-center justify-between shrink-0">
                        <div className="flex items-center gap-1">
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mr-2">Önizleme</span>
                            <button onClick={() => setPreviewDevice("desktop")} className={`p-1.5 rounded transition ${previewDevice === "desktop" ? "bg-blue-100 text-blue-600" : "text-gray-400"}`}><ComputerDesktopIcon className="w-4 h-4" /></button>
                            <button onClick={() => setPreviewDevice("mobile")} className={`p-1.5 rounded transition ${previewDevice === "mobile" ? "bg-blue-100 text-blue-600" : "text-gray-400"}`}><DevicePhoneMobileIcon className="w-4 h-4" /></button>
                        </div>
                        <div className="flex items-center gap-1">
                            <button onClick={() => setPreviewZoom(Math.max(30, previewZoom - 10))} className="p-1 text-gray-400"><MagnifyingGlassMinusIcon className="w-4 h-4" /></button>
                            <span className="text-[10px] font-bold text-gray-500 w-8 text-center">{previewZoom}%</span>
                            <button onClick={() => setPreviewZoom(Math.min(100, previewZoom + 10))} className="p-1 text-gray-400"><MagnifyingGlassPlusIcon className="w-4 h-4" /></button>
                            <div className="w-px h-4 bg-gray-200 mx-1" />
                            <button onClick={() => { if (iframeRef.current) iframeRef.current.src = iframeRef.current.src; }} className="p-1 text-gray-400"><ArrowPathIcon className="w-4 h-4" /></button>
                            <button onClick={() => setPreviewFullscreen(!previewFullscreen)} className="p-1 text-gray-400">{previewFullscreen ? <ArrowsPointingInIcon className="w-4 h-4" /> : <ArrowsPointingOutIcon className="w-4 h-4" />}</button>
                        </div>
                    </div>
                    <div className="flex-1 overflow-auto flex items-start justify-center p-4">
                        {(() => { const iframeW = previewDevice === "mobile" ? 375 : 1440; const iframeH = previewDevice === "mobile" ? 812 : 900; const scale = previewZoom / 100; return (
                            <div style={{ width: iframeW * scale, height: iframeH * scale, flexShrink: 0 }}>
                                <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-gray-200" style={{ width: iframeW, height: iframeH, transform: `scale(${scale})`, transformOrigin: "top left" }}>
                                    <iframe ref={iframeRef} src="/orgun-egitim" className="border-0 bg-white" style={{ width: "100%", height: "100%" }} />
                                </div>
                            </div>
                        ); })()}
                    </div>
                </div>
                </ResizableSplitter>
            </div>
        </div>
    );
}

function SectionAccordion({ id, active, expanded, toggle, children }: { id: SectionId; active: SectionId; expanded: Set<SectionId>; toggle: (id: SectionId) => void; children: React.ReactNode }) {
    const meta = SECTION_META[id]; const Icon = meta.icon; const isActive = active === id; const isExpanded = expanded.has(id);
    return (
        <div className={`bg-white rounded-xl border transition-all ${isActive ? "border-blue-300 shadow-md shadow-blue-100/50 ring-1 ring-blue-200" : "border-gray-200"}`}>
            <button onClick={() => toggle(id)} className="w-full px-4 py-3 flex items-center gap-3 text-left">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${meta.color}`}><Icon className="w-4 h-4" /></div>
                <span className="text-sm font-bold text-gray-800 flex-1">{meta.label}</span>
                {isActive && <span className="text-[9px] bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full font-bold">Düzenleniyor</span>}
                <ChevronDownIcon className={`w-4 h-4 text-gray-400 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
            </button>
            {isExpanded && <div className="px-4 pb-4 pt-1 border-t border-gray-100">{children}</div>}
        </div>
    );
}
