"use client";
// Dosya Yolu: app/components/CourseCard.tsx
// GÜNCELLENMİŞ TASARIM: Detaylı Liste Görünümü
// - Temiz görsel
// - Özellikler listesi (Yeşil tikli)
// - Müfredat bilgisi
// - Taksit seçeneği ve İkili buton

import {
  ClockIcon,
  UserGroupIcon,
  PlayCircleIcon,
  CheckIcon,
  ShoppingCartIcon,
  EyeIcon,
} from "@heroicons/react/24/solid";

import {
  CheckCircleIcon
} from "@heroicons/react/24/outline";
import { useCart } from "@/app/components/cart/cartStore";

type CourseCardProps = {
  slug: string;
  title: string;
  category: string;
  type?: string;
  imageUrl: string;
  originalPrice: string;
  discountedPrice: string;
  duration: string;
  studentCount: string;
  isNew?: boolean;
  isNew?: boolean;
  seatsLeft?: number;
  learningOutcomes?: string[] | null;
  questions?: string | null;
  color?: string;
  emoji?: string;
};

function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

function moneyToNumberLike(str: string) {
  const cleaned = (str || "")
    .replaceAll("₺", "")
    .replaceAll(".", "")
    .replaceAll(" ", "")
    .replaceAll(",", ".");
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}

function formatTL(n: number) {
  const s = Math.round(n).toString();
  return s.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export default function CourseCard({
  slug,
  title,
  category,
  imageUrl,
  originalPrice,
  discountedPrice,
  duration,
  studentCount,
  learningOutcomes,
  questions,
  color = "#3B82F6",
  emoji = "",
}: CourseCardProps) {
  const href = `/kurs/${slug}`;
  const priceVal = moneyToNumberLike(discountedPrice);
  const origPriceVal = moneyToNumberLike(originalPrice);
  const installmentPrice = priceVal > 0 ? formatTL(priceVal / 12) : "0";
  const { add } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    add({
      id: slug,
      slug,
      title,
      category,
      imageUrl,
      price: priceVal,
      originalPrice: origPriceVal,
      qty: 1
    }, { openDrawer: true });
  };

  // Veritabanından gelen Kazanımlar (learningOutcomes) array'ini kullanıyoruz
  const featuresList = Array.isArray(learningOutcomes) && learningOutcomes.length > 0 
    ? learningOutcomes 
    : [];

  return (
    <div className="group flex flex-col h-full bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-[0_20px_40px_rgba(0,0,0,0.08)] transition-all duration-300">

      {/* 1. GÖRSEL ALANI (Temiz, overlaysiz) */}
      <div className="relative h-56 overflow-hidden shrink-0">
        <a href={href} className="block w-full h-full">
          <img
            className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
            src={imageUrl}
            alt={title}
          />
        </a>
        {/* Kategori Etiketi (Sol üst) */}
        <div className="absolute top-4 left-4">
          <span 
            className="backdrop-blur-sm text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm border"
            style={{ color: color, borderColor: `${color}40`, backgroundColor: `${color}F2` /* 95% opacity white via mix-blend or just fallback to pure inline */ }}
          >
            <span style={{ filter: "brightness(0.9)", mixBlendMode: "multiply", backgroundColor: "#fff", position: "absolute", inset: 0, borderRadius: "0.5rem", zIndex: -1 }}></span>
            <span style={{ position: "relative", zIndex: 1, backgroundColor: "white", padding: "4px 8px", borderRadius: "6px" }}>{category}</span>
          </span>
        </div>
      </div>

      {/* 2. İÇERİK ALANI */}
      <div className="p-6 flex flex-col flex-grow">

        {/* Başlık */}
        <a href={href} className="block group/title">
          <h3 
            className="text-xl font-bold text-gray-900 leading-snug mb-4 transition-colors [&>p]:inline"
          >
            <span className="group-hover/title:text-[var(--hover-color)] transition-colors" style={{ '--hover-color': color } as React.CSSProperties} dangerouslySetInnerHTML={{ __html: title }} />
          </h3>
        </a>

        {/* --- Özellikler Listesi --- */}
        {featuresList.length > 0 && (
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-green-600 mb-3">Kazanımlar</h4>
            <ul className="space-y-2">
              {featuresList.map((feature, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                  <CheckIcon className="w-5 h-5 text-green-500 shrink-0" />
                  <span className="leading-tight">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* --- Müfredat Bilgisi --- */}
        {(duration || questions || studentCount) ? (
          <div className="mb-6 pt-4 border-t border-dashed border-gray-200">
            <h4 className="text-sm font-semibold text-green-600 mb-3">Genel Bakış</h4>
            <div className="space-y-2">
              {duration && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircleIcon className="w-5 h-5 text-green-500 shrink-0" />
                  <span>{duration}</span>
                </div>
              )}
              {questions && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <CheckCircleIcon className="w-5 h-5 text-green-500 shrink-0" />
                  <span>{questions}</span>
                </div>
              )}
              {studentCount && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <UserGroupIcon className="w-5 h-5 text-blue-400 shrink-0" />
                  <span>{studentCount}</span>
                </div>
              )}
            </div>
          </div>
        ) : null}

        {/* --- Fiyat ve Taksit --- */}
        <div className="mt-auto">
          {/* Büyük Fiyat */}
          <div className="flex items-baseline gap-3 mb-2">
            <span className="text-3xl font-extrabold text-blue-900">
              {discountedPrice}
            </span>
            {originalPrice && originalPrice !== discountedPrice && (
              <span className="text-sm text-gray-400 line-through decoration-red-400 decoration-1">
                {originalPrice}
              </span>
            )}
          </div>

          {/* Taksit Bandı */}
          <div className="bg-green-50 border border-green-100 rounded-lg p-2.5 text-center mb-6">
            <span className="text-sm font-bold text-green-800">
              Peşin Fiyatına 12 Taksit ( Aylık {installmentPrice} TL )
            </span>
          </div>

          {/* --- Butonlar (Dual) --- */}
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={handleAddToCart}
              className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border-2 font-bold transition-all duration-300"
              style={{ borderColor: color, color: color, backgroundColor: "transparent" }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = `${color}1A`}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = "transparent"}
            >
              <ShoppingCartIcon className="w-5 h-5" />
              Hemen Al
            </button>
            <a
              href={href}
              className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-white font-bold transition-all duration-300 shadow-lg shadow-gray-200"
              style={{ backgroundColor: color }}
              onMouseEnter={(e) => e.currentTarget.style.filter = "brightness(0.9)"}
              onMouseLeave={(e) => e.currentTarget.style.filter = "brightness(1)"}
            >
              <EyeIcon className="w-5 h-5" />
              Detaya Bak
            </a>
          </div>

        </div>

      </div>
    </div>
  );
}
